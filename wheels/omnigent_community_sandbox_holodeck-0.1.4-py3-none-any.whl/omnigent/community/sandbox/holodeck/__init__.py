"""Holodeck sandbox provider for Omnigent (community plugin)."""
